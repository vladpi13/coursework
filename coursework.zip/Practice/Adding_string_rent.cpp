#include "Adding_string_rent.h"

