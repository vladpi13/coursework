#include "Base_of_rent.h"

