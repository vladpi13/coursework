#include "password.h"
#include "base_of_buy.h"
#include "Base_of_rent.h"
#include "Base_of_rent_months.h"
#include "Information.h"
#include <io.h>

#pragma once

namespace Practice {
	
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	
	/// <summary>
	/// ������ ��� main_menu
	/// </summary>
	
	public ref class Main_menu : public System::Windows::Forms::Form
	{
	public: int flag;
		
		 
	public:



		
		Main_menu(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Main_menu()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ admin_button1;
	private: System::Windows::Forms::Button^ user_button1;
	private: System::Windows::Forms::Button^ info_button1;
	private: System::Windows::Forms::Button^ exit_button1;
	private: System::Windows::Forms::Button^ buy_button1;
	private: System::Windows::Forms::Button^ rent_button1;
	private: System::Windows::Forms::Button^ rent_days_button1;
	private: System::Windows::Forms::Button^ rent_months_button1;





	private: System::Windows::Forms::Button^ admin_buy_button1;
	private: System::Windows::Forms::Button^ admin_rent_button1;
	private: System::Windows::Forms::Button^ admin_rent_days_button1;
	private: System::Windows::Forms::Button^ admin_rent_months_button1;







	protected:

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Main_menu::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->admin_button1 = (gcnew System::Windows::Forms::Button());
			this->user_button1 = (gcnew System::Windows::Forms::Button());
			this->info_button1 = (gcnew System::Windows::Forms::Button());
			this->exit_button1 = (gcnew System::Windows::Forms::Button());
			this->buy_button1 = (gcnew System::Windows::Forms::Button());
			this->rent_button1 = (gcnew System::Windows::Forms::Button());
			this->rent_days_button1 = (gcnew System::Windows::Forms::Button());
			this->rent_months_button1 = (gcnew System::Windows::Forms::Button());
			this->admin_buy_button1 = (gcnew System::Windows::Forms::Button());
			this->admin_rent_button1 = (gcnew System::Windows::Forms::Button());
			this->admin_rent_days_button1 = (gcnew System::Windows::Forms::Button());
			this->admin_rent_months_button1 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->ForeColor = System::Drawing::Color::DarkBlue;
			this->label1->Location = System::Drawing::Point(92, 125);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(254, 25);
			this->label1->TabIndex = 0;
			this->label1->Text = L"�������� ������������";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->ForeColor = System::Drawing::Color::DarkBlue;
			this->label2->Location = System::Drawing::Point(92, 190);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(340, 25);
			this->label2->TabIndex = 1;
			this->label2->Text = L"�������� ��������� ��� �����";
			// 
			// admin_button1
			// 
			this->admin_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->admin_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->admin_button1->Location = System::Drawing::Point(48, 250);
			this->admin_button1->Margin = System::Windows::Forms::Padding(4);
			this->admin_button1->Name = L"admin_button1";
			this->admin_button1->Size = System::Drawing::Size(185, 45);
			this->admin_button1->TabIndex = 2;
			this->admin_button1->Text = L"�������������";
			this->admin_button1->UseVisualStyleBackColor = false;
			this->admin_button1->Click += gcnew System::EventHandler(this, &Main_menu::admin_button1_Click);
			// 
			// user_button1
			// 
			this->user_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->user_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->user_button1->Location = System::Drawing::Point(355, 250);
			this->user_button1->Margin = System::Windows::Forms::Padding(4);
			this->user_button1->Name = L"user_button1";
			this->user_button1->Size = System::Drawing::Size(195, 45);
			this->user_button1->TabIndex = 3;
			this->user_button1->Text = L"������������";
			this->user_button1->UseVisualStyleBackColor = false;
			this->user_button1->Click += gcnew System::EventHandler(this, &Main_menu::user_button1_Click);
			// 
			// info_button1
			// 
			this->info_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->info_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->info_button1->Location = System::Drawing::Point(346, 13);
			this->info_button1->Name = L"info_button1";
			this->info_button1->Size = System::Drawing::Size(115, 30);
			this->info_button1->TabIndex = 4;
			this->info_button1->Text = L"�������";
			this->info_button1->UseVisualStyleBackColor = false;
			this->info_button1->Click += gcnew System::EventHandler(this, &Main_menu::info_button1_Click);
			// 
			// exit_button1
			// 
			this->exit_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->exit_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->exit_button1->Location = System::Drawing::Point(469, 13);
			this->exit_button1->Margin = System::Windows::Forms::Padding(4);
			this->exit_button1->Name = L"exit_button1";
			this->exit_button1->Size = System::Drawing::Size(116, 30);
			this->exit_button1->TabIndex = 5;
			this->exit_button1->Text = L"�����";
			this->exit_button1->UseVisualStyleBackColor = false;
			this->exit_button1->Click += gcnew System::EventHandler(this, &Main_menu::exit_button1_Click);
			// 
			// buy_button1
			// 
			this->buy_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->buy_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->buy_button1->Location = System::Drawing::Point(304, 320);
			this->buy_button1->Margin = System::Windows::Forms::Padding(4);
			this->buy_button1->Name = L"buy_button1";
			this->buy_button1->Size = System::Drawing::Size(128, 45);
			this->buy_button1->TabIndex = 6;
			this->buy_button1->Text = L"������";
			this->buy_button1->UseVisualStyleBackColor = false;
			this->buy_button1->Visible = false;
			this->buy_button1->Click += gcnew System::EventHandler(this, &Main_menu::buy_button1_Click_1);
			// 
			// rent_button1
			// 
			this->rent_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->rent_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->rent_button1->Location = System::Drawing::Point(460, 320);
			this->rent_button1->Margin = System::Windows::Forms::Padding(4);
			this->rent_button1->Name = L"rent_button1";
			this->rent_button1->Size = System::Drawing::Size(126, 45);
			this->rent_button1->TabIndex = 7;
			this->rent_button1->Text = L"�����";
			this->rent_button1->UseVisualStyleBackColor = false;
			this->rent_button1->Visible = false;
			this->rent_button1->Click += gcnew System::EventHandler(this, &Main_menu::rent_button1_Click);
			// 
			// rent_days_button1
			// 
			this->rent_days_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->rent_days_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->rent_days_button1->Location = System::Drawing::Point(304, 373);
			this->rent_days_button1->Margin = System::Windows::Forms::Padding(4);
			this->rent_days_button1->Name = L"rent_days_button1";
			this->rent_days_button1->Size = System::Drawing::Size(126, 45);
			this->rent_days_button1->TabIndex = 8;
			this->rent_days_button1->Text = L"���������";
			this->rent_days_button1->UseVisualStyleBackColor = false;
			this->rent_days_button1->Visible = false;
			this->rent_days_button1->Click += gcnew System::EventHandler(this, &Main_menu::rent_days_button1_Click);
			// 
			// rent_months_button1
			// 
			this->rent_months_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->rent_months_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->rent_months_button1->Location = System::Drawing::Point(460, 373);
			this->rent_months_button1->Margin = System::Windows::Forms::Padding(4);
			this->rent_months_button1->Name = L"rent_months_button1";
			this->rent_months_button1->Size = System::Drawing::Size(126, 45);
			this->rent_months_button1->TabIndex = 9;
			this->rent_months_button1->Text = L"�����������";
			this->rent_months_button1->UseVisualStyleBackColor = false;
			this->rent_months_button1->Visible = false;
			this->rent_months_button1->Click += gcnew System::EventHandler(this, &Main_menu::rent_months_button1_Click);
			// 
			// admin_buy_button1
			// 
			this->admin_buy_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->admin_buy_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->admin_buy_button1->Location = System::Drawing::Point(4, 320);
			this->admin_buy_button1->Margin = System::Windows::Forms::Padding(4);
			this->admin_buy_button1->Name = L"admin_buy_button1";
			this->admin_buy_button1->Size = System::Drawing::Size(128, 45);
			this->admin_buy_button1->TabIndex = 10;
			this->admin_buy_button1->Text = L"������";
			this->admin_buy_button1->UseVisualStyleBackColor = false;
			this->admin_buy_button1->Visible = false;
			this->admin_buy_button1->Click += gcnew System::EventHandler(this, &Main_menu::admin_buy_button1_Click);
			// 
			// admin_rent_button1
			// 
			this->admin_rent_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->admin_rent_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->admin_rent_button1->Location = System::Drawing::Point(155, 320);
			this->admin_rent_button1->Margin = System::Windows::Forms::Padding(4);
			this->admin_rent_button1->Name = L"admin_rent_button1";
			this->admin_rent_button1->Size = System::Drawing::Size(128, 45);
			this->admin_rent_button1->TabIndex = 11;
			this->admin_rent_button1->Text = L"�����";
			this->admin_rent_button1->UseVisualStyleBackColor = false;
			this->admin_rent_button1->Visible = false;
			this->admin_rent_button1->Click += gcnew System::EventHandler(this, &Main_menu::admin_rent_button1_Click);
			// 
			// admin_rent_days_button1
			// 
			this->admin_rent_days_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->admin_rent_days_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->admin_rent_days_button1->Location = System::Drawing::Point(6, 373);
			this->admin_rent_days_button1->Margin = System::Windows::Forms::Padding(4);
			this->admin_rent_days_button1->Name = L"admin_rent_days_button1";
			this->admin_rent_days_button1->Size = System::Drawing::Size(126, 45);
			this->admin_rent_days_button1->TabIndex = 12;
			this->admin_rent_days_button1->Text = L"���������";
			this->admin_rent_days_button1->UseVisualStyleBackColor = false;
			this->admin_rent_days_button1->Visible = false;
			this->admin_rent_days_button1->Click += gcnew System::EventHandler(this, &Main_menu::admin_rent_days_button1_Click);
			// 
			// admin_rent_months_button1
			// 
			this->admin_rent_months_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->admin_rent_months_button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->admin_rent_months_button1->Location = System::Drawing::Point(155, 373);
			this->admin_rent_months_button1->Margin = System::Windows::Forms::Padding(4);
			this->admin_rent_months_button1->Name = L"admin_rent_months_button1";
			this->admin_rent_months_button1->Size = System::Drawing::Size(126, 45);
			this->admin_rent_months_button1->TabIndex = 13;
			this->admin_rent_months_button1->Text = L"�����������";
			this->admin_rent_months_button1->UseVisualStyleBackColor = false;
			this->admin_rent_months_button1->Visible = false;
			this->admin_rent_months_button1->Click += gcnew System::EventHandler(this, &Main_menu::admin_rent_months_button1_Click);
			// 
			// Main_menu
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightBlue;
			this->ClientSize = System::Drawing::Size(598, 437);
			this->Controls->Add(this->admin_rent_months_button1);
			this->Controls->Add(this->admin_rent_days_button1);
			this->Controls->Add(this->admin_rent_button1);
			this->Controls->Add(this->admin_buy_button1);
			this->Controls->Add(this->rent_months_button1);
			this->Controls->Add(this->rent_days_button1);
			this->Controls->Add(this->rent_button1);
			this->Controls->Add(this->buy_button1);
			this->Controls->Add(this->exit_button1);
			this->Controls->Add(this->info_button1);
			this->Controls->Add(this->user_button1);
			this->Controls->Add(this->admin_button1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->ForeColor = System::Drawing::SystemColors::ControlText;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"Main_menu";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"����� ������";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void admin_button1_Click(System::Object^ sender, System::EventArgs^ e) {
		admin_buy_button1->Visible = true;
		admin_rent_button1->Visible = true;
		rent_button1->Visible = false;
		buy_button1->Visible = false;
		rent_days_button1->Visible = false;
		rent_months_button1->Visible = false;


	}
	private: System::Void user_button1_Click(System::Object^ sender, System::EventArgs^ e) {
		buy_button1->Visible = true;
		rent_button1->Visible = true;

		admin_buy_button1->Visible = false;
		admin_rent_button1->Visible = false;
		admin_rent_days_button1->Visible = false;
		admin_rent_months_button1->Visible = false;
		
	}
	private: System::Void info_button1_Click(System::Object^ sender, System::EventArgs^ e) {
		Information^ inf = gcnew Information();
		inf->Show();
	}
	private: System::Void exit_button1_Click(System::Object^ sender, System::EventArgs^ e) {
		Application::Exit();
	}

	private: System::Void buy_button1_Click(System::Object^ sender, System::EventArgs^ e) {
		
		if (flag == 0)
		{

			Base_of_rent^ open = gcnew Base_of_rent;

			open->add_menu->Visible = false;
			open->delete_line_menu->Visible = false;
			open->delete_file_menu->Visible = false;
			open->change_line_menu->Visible = false;
			open->create_file_menu->Visible = false;
			extern int flag;
			open->Show();
			open->Owner = this;
			this->Hide();

		}
	}



private: System::Void buy_button1_Click_1(System::Object^ sender, System::EventArgs^ e) {
	Base_of_buy^ open = gcnew Base_of_buy;
	open->add_menu->Visible = false;
	open->delete_line_menu->Visible = false;
	open->delete_file_menu->Visible = false;
	open->change_line_menu->Visible = false;
	open->create_file_menu->Visible = false;

	open->Show();
	open->Owner = this;
	this->Hide();
	buy_button1->Visible = false;
	rent_button1->Visible = false;
}
private: System::Void admin_buy_button1_Click(System::Object^ sender, System::EventArgs^ e) {
	admin_buy_button1->Visible = false;
	admin_rent_button1->Visible = false;
	Password^ pass = gcnew Password;
	pass->ShowDialog();
	bool next_work = pass->prov_pass;
	if (next_work == true)
	{
		Base_of_buy^ admin_open = gcnew Base_of_buy;
		admin_open->Show();
		admin_open->Owner = this;
		this->Hide();
		admin_buy_button1->Visible = false;
		admin_rent_button1->Visible = false;
	}
}
private: System::Void rent_days_button1_Click(System::Object^ sender, System::EventArgs^ e) {
	admin_buy_button1->Visible = false;
	admin_rent_button1->Visible = false;
	admin_rent_days_button1->Visible = false;
	admin_rent_months_button1->Visible = false;
	Base_of_rent^ open = gcnew Base_of_rent;
	open->add_menu->Visible = false;
	open->delete_line_menu->Visible = false;
	open->delete_file_menu->Visible = false;
	open->change_line_menu->Visible = false;
	open->create_file_menu->Visible = false;

	open->Show();
	open->Owner = this;
	this->Hide();
	rent_days_button1->Visible = false;
	rent_months_button1->Visible = false;
	rent_button1->Visible = false;

}
private: System::Void rent_button1_Click(System::Object^ sender, System::EventArgs^ e) {
	buy_button1->Visible = false;
	admin_buy_button1->Visible = false;
	admin_rent_button1->Visible = false;
	admin_rent_days_button1->Visible = false;
	admin_rent_months_button1->Visible = false;
	rent_days_button1->Visible = true;
	rent_months_button1->Visible = true;

}
private: System::Void admin_rent_button1_Click(System::Object^ sender, System::EventArgs^ e) {
	admin_buy_button1->Visible = false;
	admin_rent_days_button1->Visible = true;
	admin_rent_months_button1->Visible = true;
}
private: System::Void admin_rent_days_button1_Click(System::Object^ sender, System::EventArgs^ e) {
	admin_buy_button1->Visible = false;
	admin_rent_button1->Visible = false;
	admin_rent_days_button1->Visible = false;
	admin_rent_months_button1->Visible = false;
	Password^ pass = gcnew Password;
	pass->ShowDialog();
	bool next_work = pass->prov_pass;
	if (next_work == true)
	{
		Base_of_rent^ open = gcnew Base_of_rent;
		open->Show();
		open->Owner = this;
		this->Hide();
		admin_rent_months_button1->Visible = false;
		admin_rent_days_button1->Visible = false;
		admin_rent_button1->Visible = false;
	}
}
private: System::Void admin_rent_months_button1_Click(System::Object^ sender, System::EventArgs^ e) {
	admin_buy_button1->Visible = false;
	admin_rent_button1->Visible = false;
	admin_rent_days_button1->Visible = false;
	admin_rent_months_button1->Visible = false;
	Password^ pass = gcnew Password;
	pass->ShowDialog();
	bool next_work = pass->prov_pass;
	if (next_work == true)
	{
		Base_of_rent_months^ open = gcnew Base_of_rent_months;
		open->Show();
		open->Owner = this;
		this->Hide();
		admin_rent_months_button1->Visible = false;
		admin_rent_days_button1->Visible = false;
		admin_rent_button1->Visible = false;
	}
}
private: System::Void rent_months_button1_Click(System::Object^ sender, System::EventArgs^ e) {
	admin_buy_button1->Visible = false;
	admin_rent_button1->Visible = false;
	admin_rent_days_button1->Visible = false;
	admin_rent_months_button1->Visible = false;
	Base_of_rent_months^ open = gcnew Base_of_rent_months;
	open->add_menu->Visible = false;
	open->delete_line_menu->Visible = false;
	open->delete_file_menu->Visible = false;
	open->change_line_menu->Visible = false;
	open->create_file_menu->Visible = false;

	open->Show();
	open->Owner = this;
	this->Hide();
	rent_months_button1->Visible = false;
	rent_days_button1->Visible = false;
	rent_button1->Visible = false;
}
};
}
