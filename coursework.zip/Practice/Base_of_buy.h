#include"Adding_string.h"
#include"Request.h"
#include"Information.h"


namespace Practice {
	
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	/// <summary>
	/// ������ ��� Base_of_buy
	/// </summary>
	
	public ref class Base_of_buy : public System::Windows::Forms::Form
	{

	public:  // ������ �� ���, ����� ����� ������� (������� ��� ������ ��������)
	public:
	
		Base_of_buy(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}
	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Base_of_buy()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::MenuStrip^ base_menuStrip1;
	protected:
	public: System::Windows::Forms::ToolStripMenuItem^ add_menu;
	public: System::Windows::Forms::ToolStripMenuItem^ delete_line_menu;
	public: System::Windows::Forms::ToolStripMenuItem^ change_line_menu;
	public: System::Windows::Forms::ToolStripMenuItem^ request_menu;
	public: System::Windows::Forms::ToolStripMenuItem^ create_file_menu;
	public: System::Windows::Forms::ToolStripMenuItem^ delete_file_menu;
	public: System::Windows::Forms::ToolStripMenuItem^ exit_menu;
	private: System::Windows::Forms::DataGridView^ base_of_buy_dataGridView1;
	public:
	private: System::Windows::Forms::Label^ delete_line_label1;

	private: System::Windows::Forms::Button^ delete_line_button1;
	private: System::Windows::Forms::Label^ change_line_label1;

	private: System::Windows::Forms::Button^ change_line_button1;

	protected:


	protected:
	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
	public: bool save_all = true; //���������� ��� �������� ���������� ������

	public:
	private: System::Windows::Forms::TextBox^ delete_line_textBox1;
	private: System::Windows::Forms::Button^ otm_delete_button1;
	private: System::Windows::Forms::Button^ otm_change_button1;
	private: System::Windows::Forms::TextBox^ chnage_line_textBox1;

	private: System::Windows::Forms::ToolStripMenuItem^ info_menu;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ nomer_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ city_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ data_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ educate_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ speciality_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ position_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ price_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ telephone1_Column1;





		   		   	   	
		   		   		      	   


		   int nomer_row;
#pragma region Windows Form Designer generated code
		   /// <summary>
		   /// ��������� ����� ��� ��������� ������������ � �� ��������� 
		   /// ���������� ����� ������ � ������� ��������� ����.
		   /// </summary>
		   void InitializeComponent(void)
		   {
			   System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Base_of_buy::typeid));
			   this->base_menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			   this->add_menu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			   this->delete_line_menu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			   this->change_line_menu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			   this->request_menu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			   this->info_menu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			   this->create_file_menu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			   this->delete_file_menu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			   this->exit_menu = (gcnew System::Windows::Forms::ToolStripMenuItem());
			   this->base_of_buy_dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			   this->delete_line_label1 = (gcnew System::Windows::Forms::Label());
			   this->delete_line_button1 = (gcnew System::Windows::Forms::Button());
			   this->change_line_label1 = (gcnew System::Windows::Forms::Label());
			   this->change_line_button1 = (gcnew System::Windows::Forms::Button());
			   this->delete_line_textBox1 = (gcnew System::Windows::Forms::TextBox());
			   this->otm_delete_button1 = (gcnew System::Windows::Forms::Button());
			   this->otm_change_button1 = (gcnew System::Windows::Forms::Button());
			   this->chnage_line_textBox1 = (gcnew System::Windows::Forms::TextBox());
			   this->nomer_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			   this->city_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			   this->data_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			   this->educate_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			   this->speciality_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			   this->position_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			   this->price_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			   this->telephone1_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			   this->base_menuStrip1->SuspendLayout();
			   (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->base_of_buy_dataGridView1))->BeginInit();
			   this->SuspendLayout();
			   // 
			   // base_menuStrip1
			   // 
			   this->base_menuStrip1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)),
				   static_cast<System::Int32>(static_cast<System::Byte>(224)));
			   this->base_menuStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
			   this->base_menuStrip1->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			   this->base_menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(8) {
				   this->add_menu, this->delete_line_menu,
					   this->change_line_menu, this->request_menu, this->info_menu, this->create_file_menu, this->delete_file_menu, this->exit_menu
			   });
			   this->base_menuStrip1->Location = System::Drawing::Point(0, 0);
			   this->base_menuStrip1->Name = L"base_menuStrip1";
			   this->base_menuStrip1->Size = System::Drawing::Size(1062, 24);
			   this->base_menuStrip1->TabIndex = 0;
			   this->base_menuStrip1->Text = L"menuStrip1";
			   this->base_menuStrip1->ItemClicked += gcnew System::Windows::Forms::ToolStripItemClickedEventHandler(this, &Base_of_buy::base_menuStrip1_ItemClicked);
			   // 
			   // add_menu
			   // 
			   this->add_menu->Name = L"add_menu";
			   this->add_menu->Size = System::Drawing::Size(111, 20);
			   this->add_menu->Text = L"�������� ������";
			   this->add_menu->Click += gcnew System::EventHandler(this, &Base_of_buy::add_menu_Click);
			   // 
			   // delete_line_menu
			   // 
			   this->delete_line_menu->Name = L"delete_line_menu";
			   this->delete_line_menu->Size = System::Drawing::Size(103, 20);
			   this->delete_line_menu->Text = L"������� ������";
			   this->delete_line_menu->Click += gcnew System::EventHandler(this, &Base_of_buy::delete_menu_Click);
			   // 
			   // change_line_menu
			   // 
			   this->change_line_menu->Name = L"change_line_menu";
			   this->change_line_menu->Size = System::Drawing::Size(139, 20);
			   this->change_line_menu->Text = L"������������� ������";
			   this->change_line_menu->Click += gcnew System::EventHandler(this, &Base_of_buy::change_menu_Click);
			   // 
			   // request_menu
			   // 
			   this->request_menu->Name = L"request_menu";
			   this->request_menu->Size = System::Drawing::Size(59, 20);
			   this->request_menu->Text = L"������";
			   this->request_menu->Click += gcnew System::EventHandler(this, &Base_of_buy::request_menu_Click);
			   // 
			   // info_menu
			   // 
			   this->info_menu->Name = L"info_menu";
			   this->info_menu->Size = System::Drawing::Size(65, 20);
			   this->info_menu->Text = L"�������";
			   this->info_menu->Click += gcnew System::EventHandler(this, &Base_of_buy::info_menu_Click);
			   // 
			   // create_file_menu
			   // 
			   this->create_file_menu->Name = L"create_file_menu";
			   this->create_file_menu->Size = System::Drawing::Size(78, 20);
			   this->create_file_menu->Text = L"���������";
			   this->create_file_menu->Click += gcnew System::EventHandler(this, &Base_of_buy::create_file_menu_Click);
			   // 
			   // delete_file_menu
			   // 
			   this->delete_file_menu->Name = L"delete_file_menu";
			   this->delete_file_menu->Size = System::Drawing::Size(95, 20);
			   this->delete_file_menu->Text = L"������� ����";
			   this->delete_file_menu->Click += gcnew System::EventHandler(this, &Base_of_buy::delete_file_menu_Click);
			   // 
			   // exit_menu
			   // 
			   this->exit_menu->Name = L"exit_menu";
			   this->exit_menu->Size = System::Drawing::Size(54, 20);
			   this->exit_menu->Text = L"�����";
			   this->exit_menu->Click += gcnew System::EventHandler(this, &Base_of_buy::exit_menu_Click);
			   // 
			   // base_ob_buy_dataGridView1
			   // 
			   this->base_of_buy_dataGridView1->AllowUserToAddRows = false;
			   this->base_of_buy_dataGridView1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			   this->base_of_buy_dataGridView1->BackgroundColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)),
				   static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)));
			   this->base_of_buy_dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			   this->base_of_buy_dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(8) {
				   this->nomer_Column1,
					   this->city_Column1, this->data_Column1, this->educate_Column1, this->speciality_Column1, this->position_Column1, this->price_Column1,
					   this->telephone1_Column1
			   });
			   this->base_of_buy_dataGridView1->Location = System::Drawing::Point(0, 31);
			   this->base_of_buy_dataGridView1->Name = L"base_ob_buy_dataGridView1";
			   this->base_of_buy_dataGridView1->RowHeadersWidth = 51;
			   this->base_of_buy_dataGridView1->RowTemplate->Height = 24;
			   this->base_of_buy_dataGridView1->Size = System::Drawing::Size(1050, 202);
			   this->base_of_buy_dataGridView1->TabIndex = 1;
			   // 
			   // delete_line_label1
			   // 
			   this->delete_line_label1->AutoSize = true;
			   this->delete_line_label1->Location = System::Drawing::Point(387, 263);
			   this->delete_line_label1->Name = L"delete_line_label1";
			   this->delete_line_label1->Size = System::Drawing::Size(264, 20);
			   this->delete_line_label1->TabIndex = 2;
			   this->delete_line_label1->Text = L"������� ����� ������ ��� ��������";
			   this->delete_line_label1->Visible = false;
			   // 
			   // delete_line_button1
			   // 
			   this->delete_line_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			   this->delete_line_button1->Location = System::Drawing::Point(391, 347);
			   this->delete_line_button1->Name = L"delete_line_button1";
			   this->delete_line_button1->Size = System::Drawing::Size(100, 37);
			   this->delete_line_button1->TabIndex = 4;
			   this->delete_line_button1->Text = L"�������";
			   this->delete_line_button1->UseVisualStyleBackColor = false;
			   this->delete_line_button1->Visible = false;
			   this->delete_line_button1->Click += gcnew System::EventHandler(this, &Base_of_buy::delete_line_button1_Click);
			   // 
			   // change_line_label1
			   // 
			   this->change_line_label1->AutoSize = true;
			   this->change_line_label1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				   static_cast<System::Byte>(204)));
			   this->change_line_label1->Location = System::Drawing::Point(362, 263);
			   this->change_line_label1->Name = L"change_line_label1";
			   this->change_line_label1->Size = System::Drawing::Size(327, 21);
			   this->change_line_label1->TabIndex = 5;
			   this->change_line_label1->Text = L"������� ����� ������, ����� ��������";
			   this->change_line_label1->Visible = false;
			   // 
			   // change_line_button1
			   // 
			   this->change_line_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			   this->change_line_button1->Location = System::Drawing::Point(391, 347);
			   this->change_line_button1->Name = L"change_line_button1";
			   this->change_line_button1->Size = System::Drawing::Size(116, 37);
			   this->change_line_button1->TabIndex = 7;
			   this->change_line_button1->Text = L"��������";
			   this->change_line_button1->UseVisualStyleBackColor = false;
			   this->change_line_button1->Visible = false;
			   this->change_line_button1->Click += gcnew System::EventHandler(this, &Base_of_buy::change_line_button1_Click);
			   // 
			   // delete_line_textBox1
			   // 
			   this->delete_line_textBox1->Location = System::Drawing::Point(476, 303);
			   this->delete_line_textBox1->Name = L"delete_line_textBox1";
			   this->delete_line_textBox1->Size = System::Drawing::Size(100, 25);
			   this->delete_line_textBox1->TabIndex = 8;
			   this->delete_line_textBox1->Visible = false;
			   this->delete_line_textBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Base_of_buy::delete_line_textBox1_KeyPress);
			   // 
			   // otm_delete_button1
			   // 
			   this->otm_delete_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			   this->otm_delete_button1->Location = System::Drawing::Point(547, 349);
			   this->otm_delete_button1->Name = L"otm_delete_button1";
			   this->otm_delete_button1->Size = System::Drawing::Size(104, 35);
			   this->otm_delete_button1->TabIndex = 9;
			   this->otm_delete_button1->Text = L"��������";
			   this->otm_delete_button1->UseVisualStyleBackColor = false;
			   this->otm_delete_button1->Visible = false;
			   this->otm_delete_button1->Click += gcnew System::EventHandler(this, &Base_of_buy::otm_delete_button1_Click);
			   // 
			   // otm_change_button1
			   // 
			   this->otm_change_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			   this->otm_change_button1->Location = System::Drawing::Point(544, 347);
			   this->otm_change_button1->Name = L"otm_change_button1";
			   this->otm_change_button1->Size = System::Drawing::Size(107, 37);
			   this->otm_change_button1->TabIndex = 10;
			   this->otm_change_button1->Text = L"��������";
			   this->otm_change_button1->UseVisualStyleBackColor = false;
			   this->otm_change_button1->Visible = false;
			   this->otm_change_button1->Click += gcnew System::EventHandler(this, &Base_of_buy::otm_change_button1_Click);
			   // 
			   // chnage_line_textBox1
			   // 
			   this->chnage_line_textBox1->Location = System::Drawing::Point(476, 303);
			   this->chnage_line_textBox1->Name = L"chnage_line_textBox1";
			   this->chnage_line_textBox1->Size = System::Drawing::Size(100, 25);
			   this->chnage_line_textBox1->TabIndex = 11;
			   this->chnage_line_textBox1->Visible = false;
			   this->chnage_line_textBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Base_of_buy::chnage_line_textBox1_KeyPress);
			   // 
			   // nomer_Column1
			   // 
			   this->nomer_Column1->HeaderText = L"�";
			   this->nomer_Column1->MinimumWidth = 6;
			   this->nomer_Column1->Name = L"nomer_Column1";
			   this->nomer_Column1->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			   // 
			   // city_Column1
			   // 
			   this->city_Column1->HeaderText = L"�����";
			   this->city_Column1->MinimumWidth = 6;
			   this->city_Column1->Name = L"city_Column1";
			   // 
			   // data_Column1
			   // 
			   this->data_Column1->FillWeight = 150;
			   this->data_Column1->HeaderText = L"����� (�����, ���)";
			   this->data_Column1->MinimumWidth = 6;
			   this->data_Column1->Name = L"data_Column1";
			   // 
			   // educate_Column1
			   // 
			   this->educate_Column1->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::ColumnHeader;
			   this->educate_Column1->HeaderText = L"����� �������";
			   this->educate_Column1->MinimumWidth = 6;
			   this->educate_Column1->Name = L"educate_Column1";
			   this->educate_Column1->Width = 137;
			   // 
			   // speciality_Column1
			   // 
			   this->speciality_Column1->AutoSizeMode = System::Windows::Forms::DataGridViewAutoSizeColumnMode::AllCells;
			   this->speciality_Column1->HeaderText = L"���-�� ������";
			   this->speciality_Column1->MinimumWidth = 6;
			   this->speciality_Column1->Name = L"speciality_Column1";
			   this->speciality_Column1->Width = 126;
			   // 
			   // position_Column1
			   // 
			   this->position_Column1->HeaderText = L"����";
			   this->position_Column1->MinimumWidth = 6;
			   this->position_Column1->Name = L"position_Column1";
			   // 
			   // price_Column1
			   // 
			   this->price_Column1->HeaderText = L"����";
			   this->price_Column1->Name = L"price_Column1";
			   // 
			   // telephone1_Column1
			   // 
			   this->telephone1_Column1->FillWeight = 120;
			   this->telephone1_Column1->HeaderText = L"�������";
			   this->telephone1_Column1->Name = L"telephone1_Column1";
			   // 
			   // Base_of_buy
			   // 
			   this->AutoScaleDimensions = System::Drawing::SizeF(8, 20);
			   this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			   this->BackColor = System::Drawing::Color::LightBlue;
			   this->ClientSize = System::Drawing::Size(1062, 453);
			   this->Controls->Add(this->chnage_line_textBox1);
			   this->Controls->Add(this->otm_change_button1);
			   this->Controls->Add(this->otm_delete_button1);
			   this->Controls->Add(this->delete_line_textBox1);
			   this->Controls->Add(this->change_line_button1);
			   this->Controls->Add(this->change_line_label1);
			   this->Controls->Add(this->delete_line_button1);
			   this->Controls->Add(this->delete_line_label1);
			   this->Controls->Add(this->base_of_buy_dataGridView1);
			   this->Controls->Add(this->base_menuStrip1);
			   this->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				   static_cast<System::Byte>(0)));
			   this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			   this->MainMenuStrip = this->base_menuStrip1;
			   this->Margin = System::Windows::Forms::Padding(4);
			   this->Name = L"Base_of_buy";
			   this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			   this->Text = L"���� ������";
			   this->Load += gcnew System::EventHandler(this, &Base_of_buy::Base_workers_Load);
			   this->base_menuStrip1->ResumeLayout(false);
			   this->base_menuStrip1->PerformLayout();
			   (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->base_of_buy_dataGridView1))->EndInit();
			   this->ResumeLayout(false);
			   this->PerformLayout();

		   }

		   //������� ���������� ����� � �������///////////////////////////////////////////////////////////////////
		   void add_str_in_table(DataGridView^ base, int count, String^ str)
		   {
			   cli::array<String^>^ newstr;
			   newstr = str->Split('/');
			   base->Rows[count]->Cells[0]->Value = count + 1;
			   for (int i = 0; i < 7; i++)
			   {
				   base->Rows[count]->Cells[i + 1]->Value = newstr[i];
			   }


		   }
#pragma endregion
	private: System::Void Base_workers_Load(System::Object^ sender, System::EventArgs^ e) {
		
		int flag;
		if (flag == 0) {

			if (IO::File::Exists("workers.txt")) {  //�������� �� ������������� �����

				StreamReader^ str = gcnew StreamReader("workers.txt");
				String^ string;
				int i = 0;
				while (str->Peek() >= 0) {
					base_of_buy_dataGridView1->Rows->Add();
					string = str->ReadLine();
					add_str_in_table(base_of_buy_dataGridView1, i, string);
					i++;
				}
				save_all = true;
				;
				str->Close();

			}
			else {
				//�������� ������ �����
				StreamWriter^ new_file = gcnew StreamWriter("workers.txt");
				delete new_file;


			}
		}
	}
	
	
		   
	
	private: System::Void lToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
	}
		   //���������� ������//////////////////////////////////////////////////////////////////////
	private: System::Void add_menu_Click(System::Object^ sender, System::EventArgs^ e)
	{
		Adding_string^ add = gcnew Adding_string();
		add->ShowDialog();
		if (add->ad_str != String::Empty) {
			base_of_buy_dataGridView1->Rows->Add();
			add_str_in_table(base_of_buy_dataGridView1, base_of_buy_dataGridView1->RowCount - 1, add->ad_str);
			save_all = false;
		}
	}
		   //���������� �����///////////////////////////////////////////////////////////////////////////////
	private: System::Void create_file_menu_Click(System::Object^ sender, System::EventArgs^ e)
	{

		StreamWriter^ ptr = gcnew StreamWriter("workers.txt");  //��������� ���� ��� ������ ������
		for (int i = 0; i < base_of_buy_dataGridView1->RowCount; i++) {
			for (int j = 1; j < 8; j++) {
				ptr->Write(base_of_buy_dataGridView1->Rows[i]->Cells[j]->Value + "/");
			}
			ptr->WriteLine();
		}
		ptr->Close();
		save_all = true;
		MessageBox::Show("���� ��������", "�����", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
		   //�������� ������////////////////////////////////////////////////////////////////////////////
	private: System::Void delete_menu_Click(System::Object^ sender, System::EventArgs^ e)
	{

		otm_delete_button1->Visible = true;
		delete_line_label1->Visible = true;
		delete_line_textBox1->Visible = true;
		delete_line_button1->Visible = true;
		save_all = false;

	}
	private: System::Void delete_line_button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (delete_line_textBox1->Text == String::Empty)
		{
			MessageBox::Show("������� ����� ������, ���� ������ �� ������� ��� ������� \"��������\"!", "������", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return;
		}
		else {
			nomer_row = int::Parse(this->delete_line_textBox1->Text);
			if (nomer_row > base_of_buy_dataGridView1->Rows->Count)
			{
				MessageBox::Show("������ ������ ���, ���������� ��� ���!", "������ �����", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;

			}
			else {
				for (int i = 0; i < base_of_buy_dataGridView1->Rows->Count; i++) {
					if (i + 1 == nomer_row)
						base_of_buy_dataGridView1->Rows->RemoveAt(i);
				}
				for (int i = 0; i < base_of_buy_dataGridView1->Rows->Count; i++) {
					base_of_buy_dataGridView1->Rows[i]->Cells[0]->Value = i + 1;
				}

			}
			delete_line_label1->Visible = false;
			delete_line_textBox1->Clear();
			delete_line_textBox1->Visible = false;
			delete_line_button1->Visible = false;
			otm_delete_button1->Visible = false;
			save_all = false;
		}
	}
		   //�������� �����////////////////////////////////////////////////////////////////////////
	private: System::Void delete_file_menu_Click(System::Object^ sender, System::EventArgs^ e)
	{
		System::Windows::Forms::DialogResult what = MessageBox::Show("������ ����� �������.\n�� �������?", "��������������", MessageBoxButtons::YesNo, MessageBoxIcon::Question);
		if (what == System::Windows::Forms::DialogResult::No)
			return;
		else {
			for (int i = 0; i < base_of_buy_dataGridView1->Rows->Count; i++) {

				base_of_buy_dataGridView1->Rows->RemoveAt(i);
				i--;
			}
			StreamWriter^ new_file = gcnew StreamWriter("workers.txt");
			delete new_file;
		}
	}
		   //�������������� ������////////////////////////////////////////////////////////////////
	private: System::Void change_menu_Click(System::Object^ sender, System::EventArgs^ e)
	{
		change_line_label1->Visible = true;
		chnage_line_textBox1->Visible = true;
		change_line_button1->Visible = true;
		otm_change_button1->Visible = true;
	}
	private: System::Void change_line_button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (chnage_line_textBox1->Text == String::Empty)
		{
			MessageBox::Show("������� ����� ������, ���� ������ �� �������� ��� ������� \"��������\"!", "������", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return;
		}
		else {
			nomer_row = int::Parse(this->chnage_line_textBox1->Text);
			if (nomer_row > base_of_buy_dataGridView1->Rows->Count)
			{
				MessageBox::Show("������ ������ ���, ���������� ��� ���!", "������ �����", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;

			}
			else {
				for (int i = 0; i < base_of_buy_dataGridView1->Rows->Count; i++) {
					if (i + 1 == nomer_row)
					{
						Adding_string^ changes = gcnew Adding_string();
						changes->Text = "������������� ������";
						changes->label1->Text = "�������� ������ ��� ����";
						changes->add_button1->Text = "��������";
						changes->city_maskedTextBox1->Text = base_of_buy_dataGridView1->Rows[i]->Cells[1]->Value + "";
						changes->data_maskedTextBox1->Text = base_of_buy_dataGridView1->Rows[i]->Cells[2]->Value + "";
						changes->division_maskedTextBox2->Text = base_of_buy_dataGridView1->Rows[i]->Cells[3]->Value + "";
						changes->payment_maskedTextBox2->Text = base_of_buy_dataGridView1->Rows[i]->Cells[4]->Value + "";
						changes->exp_specific_maskedTextBox3->Text = base_of_buy_dataGridView1->Rows[i]->Cells[5]->Value + "";
						changes->price_maskedTextBox1->Text = base_of_buy_dataGridView1->Rows[i]->Cells[6]->Value + "";
						changes->telephone_maskedTextBox1->Text = base_of_buy_dataGridView1->Rows[i]->Cells[7]->Value + "";
						
						changes->ShowDialog();
						if (changes->ad_str != String::Empty) {
							add_str_in_table(base_of_buy_dataGridView1, i, changes->ad_str);
						}
						delete changes;
					}
					save_all = false;

				}
			}
			otm_change_button1->Visible = false;
			change_line_label1->Visible = false;
			chnage_line_textBox1->Clear();
			chnage_line_textBox1->Visible = false;
			change_line_button1->Visible = false;
		}
	}
		   //������//////////////////////////////////////////////////////////////////////////////
	private: System::Void request_menu_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (save_all != false) {
			Request^ find = gcnew Request();
			find->ShowDialog();
		}
		else {
			System::Windows::Forms::DialogResult what = MessageBox::Show("������ �� ���� ���������. \n������� \"��\", ���� ������ �������� � ������������ �������.\n�������\"���\, ���� ������ �������� �� ������� �������", "��������������", MessageBoxButtons::YesNo, MessageBoxIcon::Warning);
			if (what == System::Windows::Forms::DialogResult::Yes) {
				create_file_menu_Click(sender, e);
				Request^ find_1 = gcnew Request();
				find_1->ShowDialog();
			}
			else {
				Request^ find_1 = gcnew Request();
				find_1->ShowDialog();

			}

		}
	}
		   //����� �� ��////////////////////////////////////////////////////////////////////////////////
	private: System::Void exit_menu_Click(System::Object^ sender, System::EventArgs^ e) {
		if (save_all == false)
			switch (MessageBox::Show("��� ������ �� ���� ������ ��� ������������� ������ ����� ��������.\n��������� ���������?", "��������������", MessageBoxButtons::YesNoCancel, MessageBoxIcon::Warning)) {
			case System::Windows::Forms::DialogResult::Yes: create_file_menu_Click(sender, e);  break;
			case System::Windows::Forms::DialogResult::No:break;
			case System::Windows::Forms::DialogResult::Cancel: return;
			}
		Owner->Show();
		this->Hide();


	}
	private: System::Void delete_line_textBox1_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		char number = e->KeyChar;

		if ((e->KeyChar != (char)8) && (e->KeyChar < (char)48 || e->KeyChar >(char)57)) {
			e->Handled = true;
		}
	}
	private: System::Void chnage_line_textBox1_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		char number = e->KeyChar;

		if ((e->KeyChar != (char)8) && (e->KeyChar < (char)48 || e->KeyChar >(char)57)) {
			e->Handled = true;
		}
	}
	private: System::Void otm_delete_button1_Click(System::Object^ sender, System::EventArgs^ e) {
		delete_line_label1->Visible = false;
		delete_line_textBox1->Clear();
		delete_line_textBox1->Visible = false;
		delete_line_button1->Visible = false;
		otm_delete_button1->Visible = false;
	}
	private: System::Void otm_change_button1_Click(System::Object^ sender, System::EventArgs^ e) {
		change_line_label1->Visible = false;
		chnage_line_textBox1->Clear();
		chnage_line_textBox1->Visible = false;
		change_line_button1->Visible = false;
		otm_change_button1->Visible = false;
	}
		  
	
	private: System::Void base_menuStrip1_ItemClicked(System::Object^ sender, System::Windows::Forms::ToolStripItemClickedEventArgs^ e) {
	}
		   //�������////////////////////////////////////////////////////////////////////////
	private: System::Void info_menu_Click(System::Object^ sender, System::EventArgs^ e) {
		Information^ in = gcnew Information;
		in->Show();
	}

	};
}
