#pragma once

namespace Practice {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	/// <summary>
	/// ������ ��� Request_rest_months
	/// </summary>
	public ref class Request_rent_months : public System::Windows::Forms::Form
	{
	public:
		Request_rent_months(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}
	public:  int sizes = 0, edu = 0, common = 0, specific = 0, prices = 0;
	private: System::Windows::Forms::Label^ label11;




	private: System::Windows::Forms::CheckBox^ common_min_checkBox1;
	private: System::Windows::Forms::CheckBox^ specific_min_checkBox2;
	private: System::Windows::Forms::CheckBox^ common_rav_checkBox1;
	private: System::Windows::Forms::CheckBox^ specific_rav_checkBox2;
	private: System::Windows::Forms::CheckBox^ common_max_checkBox1;
	private: System::Windows::Forms::CheckBox^ specific_maxcheckBox2;




	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::CheckBox^ price_max_checkBox2;

	private: System::Windows::Forms::CheckBox^ price_rav_checkBox2;


	private: System::Windows::Forms::CheckBox^ price_min_checkBox2;


	private: System::Windows::Forms::TextBox^ price_textBox1;
	private: System::Windows::Forms::CheckBox^ price_checkBox1;

	private: System::Windows::Forms::Label^ label6;







	private: System::Windows::Forms::CheckBox^ size_max_checkBox1;
	private: System::Windows::Forms::CheckBox^ size_rav_checkBox2;
	private: System::Windows::Forms::CheckBox^ size_min_checkBox2;
	private: System::Windows::Forms::TextBox^ size_textBox1;
	private: System::Windows::Forms::MaskedTextBox^ telephone_textBox1;


	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::CheckBox^ telephone_checkBox1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ full_name_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ data_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ speciality_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ exp_common_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ exp_specific_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ price_Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ telephone1_Column1;






	public:
	public: bool prov = false;				//���������� ��� �������� ���������� ������
	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Request_rent_months()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::CheckBox^ full_name_checkBox1;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::CheckBox^ data_checkBox1;
	private: System::Windows::Forms::CheckBox^ size_checkBox1;









	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::CheckBox^ exp_common_checkBox1;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::CheckBox^ exp_specific_checkBox1;
	private: System::Windows::Forms::MaskedTextBox^ full_name_maskedTextBox1;
	private: System::Windows::Forms::MaskedTextBox^ data_maskedTextBox1;





	private: System::Windows::Forms::Button^ request_button1;
	private: System::Windows::Forms::Button^ sbros_button2;
	private: System::Windows::Forms::DataGridView^ dataGridView1;







	private: System::Windows::Forms::Button^ return_button1;
	private: System::Windows::Forms::TextBox^ payment_textBox1;


	private: System::Windows::Forms::TextBox^ exp_specific_textBox1;

	protected:

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->full_name_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->data_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->size_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->exp_common_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->exp_specific_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->full_name_maskedTextBox1 = (gcnew System::Windows::Forms::MaskedTextBox());
			this->data_maskedTextBox1 = (gcnew System::Windows::Forms::MaskedTextBox());
			this->request_button1 = (gcnew System::Windows::Forms::Button());
			this->sbros_button2 = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->full_name_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->data_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->speciality_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->exp_common_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->exp_specific_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->price_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->telephone1_Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->return_button1 = (gcnew System::Windows::Forms::Button());
			this->payment_textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->exp_specific_textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->common_min_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->specific_min_checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->common_rav_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->specific_rav_checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->common_max_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->specific_maxcheckBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->price_max_checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->price_rav_checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->price_min_checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->price_textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->price_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->size_max_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->size_rav_checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->size_min_checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->size_textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->telephone_textBox1 = (gcnew System::Windows::Forms::MaskedTextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->telephone_checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(427, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(59, 20);
			this->label1->TabIndex = 0;
			this->label1->Text = L"������";
			this->label1->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->label1->Click += gcnew System::EventHandler(this, &Request_rent_months::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(244, 40);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(327, 20);
			this->label2->TabIndex = 1;
			this->label2->Text = L"��������� ������� ����� ������� ���������";
			this->label2->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(244, 60);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(353, 20);
			this->label3->TabIndex = 2;
			this->label3->Text = L" ����� ��������� ����������� ����� ���� ����";
			this->label3->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// full_name_checkBox1
			// 
			this->full_name_checkBox1->AutoSize = true;
			this->full_name_checkBox1->Location = System::Drawing::Point(66, 169);
			this->full_name_checkBox1->Name = L"full_name_checkBox1";
			this->full_name_checkBox1->Size = System::Drawing::Size(15, 14);
			this->full_name_checkBox1->TabIndex = 3;
			this->full_name_checkBox1->UseVisualStyleBackColor = true;
			this->full_name_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::full_name_checkBox1_Checked);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(8, 165);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(51, 20);
			this->label4->TabIndex = 4;
			this->label4->Text = L"�����";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(169, 165);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(51, 20);
			this->label5->TabIndex = 5;
			this->label5->Text = L"�����";
			// 
			// data_checkBox1
			// 
			this->data_checkBox1->AutoSize = true;
			this->data_checkBox1->Location = System::Drawing::Point(276, 171);
			this->data_checkBox1->Name = L"data_checkBox1";
			this->data_checkBox1->Size = System::Drawing::Size(15, 14);
			this->data_checkBox1->TabIndex = 6;
			this->data_checkBox1->UseVisualStyleBackColor = true;
			this->data_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::data_checkBox1_Checked);
			// 
			// size_checkBox1
			// 
			this->size_checkBox1->AutoSize = true;
			this->size_checkBox1->Location = System::Drawing::Point(473, 171);
			this->size_checkBox1->Name = L"size_checkBox1";
			this->size_checkBox1->Size = System::Drawing::Size(15, 14);
			this->size_checkBox1->TabIndex = 10;
			this->size_checkBox1->UseVisualStyleBackColor = true;
			this->size_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::speciality_checkBox1_Checked);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(8, 257);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(113, 20);
			this->label9->TabIndex = 13;
			this->label9->Text = L"���-�� ������";
			// 
			// exp_common_checkBox1
			// 
			this->exp_common_checkBox1->AutoSize = true;
			this->exp_common_checkBox1->Location = System::Drawing::Point(132, 261);
			this->exp_common_checkBox1->Name = L"exp_common_checkBox1";
			this->exp_common_checkBox1->Size = System::Drawing::Size(15, 14);
			this->exp_common_checkBox1->TabIndex = 14;
			this->exp_common_checkBox1->UseVisualStyleBackColor = true;
			this->exp_common_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::exp_common_checkBox1_Checked);
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(222, 257);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(43, 20);
			this->label10->TabIndex = 15;
			this->label10->Text = L"����";
			// 
			// exp_specific_checkBox1
			// 
			this->exp_specific_checkBox1->AutoSize = true;
			this->exp_specific_checkBox1->Location = System::Drawing::Point(342, 261);
			this->exp_specific_checkBox1->Name = L"exp_specific_checkBox1";
			this->exp_specific_checkBox1->Size = System::Drawing::Size(15, 14);
			this->exp_specific_checkBox1->TabIndex = 16;
			this->exp_specific_checkBox1->UseVisualStyleBackColor = true;
			this->exp_specific_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::exp_specific_checkBox1_Checked);
			// 
			// full_name_maskedTextBox1
			// 
			this->full_name_maskedTextBox1->Location = System::Drawing::Point(12, 191);
			this->full_name_maskedTextBox1->Name = L"full_name_maskedTextBox1";
			this->full_name_maskedTextBox1->Size = System::Drawing::Size(100, 25);
			this->full_name_maskedTextBox1->TabIndex = 17;
			this->full_name_maskedTextBox1->Visible = false;
			// 
			// data_maskedTextBox1
			// 
			this->data_maskedTextBox1->Location = System::Drawing::Point(173, 191);
			this->data_maskedTextBox1->Name = L"data_maskedTextBox1";
			this->data_maskedTextBox1->Size = System::Drawing::Size(100, 25);
			this->data_maskedTextBox1->TabIndex = 18;
			this->data_maskedTextBox1->Visible = false;
			// 
			// request_button1
			// 
			this->request_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->request_button1->Location = System::Drawing::Point(704, 283);
			this->request_button1->Name = L"request_button1";
			this->request_button1->Size = System::Drawing::Size(97, 30);
			this->request_button1->TabIndex = 24;
			this->request_button1->Text = L"�����";
			this->request_button1->UseVisualStyleBackColor = false;
			this->request_button1->Click += gcnew System::EventHandler(this, &Request_rent_months::request_button1_Click);
			// 
			// sbros_button2
			// 
			this->sbros_button2->BackColor = System::Drawing::Color::LightSteelBlue;
			this->sbros_button2->Location = System::Drawing::Point(818, 283);
			this->sbros_button2->Name = L"sbros_button2";
			this->sbros_button2->Size = System::Drawing::Size(100, 30);
			this->sbros_button2->TabIndex = 25;
			this->sbros_button2->Text = L"�����";
			this->sbros_button2->UseVisualStyleBackColor = false;
			this->sbros_button2->Click += gcnew System::EventHandler(this, &Request_rent_months::sbros_button2_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
			this->dataGridView1->BackgroundColor = System::Drawing::Color::Silver;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(7) {
				this->full_name_Column1,
					this->data_Column1, this->speciality_Column1, this->exp_common_Column1, this->exp_specific_Column1, this->price_Column1, this->telephone1_Column1
			});
			this->dataGridView1->Location = System::Drawing::Point(8, 362);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersWidth = 51;
			this->dataGridView1->RowTemplate->Height = 24;
			this->dataGridView1->Size = System::Drawing::Size(914, 150);
			this->dataGridView1->TabIndex = 26;
			// 
			// full_name_Column1
			// 
			this->full_name_Column1->HeaderText = L"�����";
			this->full_name_Column1->MinimumWidth = 6;
			this->full_name_Column1->Name = L"full_name_Column1";
			// 
			// data_Column1
			// 
			this->data_Column1->HeaderText = L"�����";
			this->data_Column1->MinimumWidth = 6;
			this->data_Column1->Name = L"data_Column1";
			// 
			// speciality_Column1
			// 
			this->speciality_Column1->HeaderText = L"����� �������";
			this->speciality_Column1->MinimumWidth = 6;
			this->speciality_Column1->Name = L"speciality_Column1";
			// 
			// exp_common_Column1
			// 
			this->exp_common_Column1->HeaderText = L"���-�� ������";
			this->exp_common_Column1->MinimumWidth = 6;
			this->exp_common_Column1->Name = L"exp_common_Column1";
			// 
			// exp_specific_Column1
			// 
			this->exp_specific_Column1->HeaderText = L"����";
			this->exp_specific_Column1->MinimumWidth = 6;
			this->exp_specific_Column1->Name = L"exp_specific_Column1";
			// 
			// price_Column1
			// 
			this->price_Column1->HeaderText = L"����";
			this->price_Column1->Name = L"price_Column1";
			// 
			// telephone1_Column1
			// 
			this->telephone1_Column1->HeaderText = L"�������";
			this->telephone1_Column1->Name = L"telephone1_Column1";
			// 
			// return_button1
			// 
			this->return_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->return_button1->Location = System::Drawing::Point(736, 3);
			this->return_button1->Name = L"return_button1";
			this->return_button1->Size = System::Drawing::Size(186, 34);
			this->return_button1->TabIndex = 27;
			this->return_button1->Text = L"����������� � ��";
			this->return_button1->UseVisualStyleBackColor = false;
			this->return_button1->Click += gcnew System::EventHandler(this, &Request_rent_months::return_button2_Click);
			// 
			// payment_textBox1
			// 
			this->payment_textBox1->Location = System::Drawing::Point(12, 285);
			this->payment_textBox1->MaxLength = 10;
			this->payment_textBox1->Name = L"payment_textBox1";
			this->payment_textBox1->Size = System::Drawing::Size(100, 25);
			this->payment_textBox1->TabIndex = 28;
			this->payment_textBox1->Visible = false;
			this->payment_textBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Request_rent_months::payment_textBox1_KeyPress);
			// 
			// exp_specific_textBox1
			// 
			this->exp_specific_textBox1->Location = System::Drawing::Point(235, 285);
			this->exp_specific_textBox1->MaxLength = 2;
			this->exp_specific_textBox1->Name = L"exp_specific_textBox1";
			this->exp_specific_textBox1->Size = System::Drawing::Size(100, 25);
			this->exp_specific_textBox1->TabIndex = 29;
			this->exp_specific_textBox1->Visible = false;
			this->exp_specific_textBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Request_rent_months::exp_specific_textBox1_KeyPress);
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(128, 94);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(570, 40);
			this->label11->TabIndex = 30;
			this->label11->Text = L"� ����� ����� ������, ��� \"������ ��������� ������\" � \"���� �� �����������\"\r\n����"
				L"� ����� ������� ���� ������� ��� ������ �� ������������";
			// 
			// common_min_checkBox1
			// 
			this->common_min_checkBox1->AutoSize = true;
			this->common_min_checkBox1->Location = System::Drawing::Point(12, 316);
			this->common_min_checkBox1->Name = L"common_min_checkBox1";
			this->common_min_checkBox1->Size = System::Drawing::Size(48, 24);
			this->common_min_checkBox1->TabIndex = 34;
			this->common_min_checkBox1->Text = L"<=";
			this->common_min_checkBox1->UseVisualStyleBackColor = true;
			this->common_min_checkBox1->Visible = false;
			this->common_min_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::common_min_checkBox1_Checked);
			// 
			// specific_min_checkBox2
			// 
			this->specific_min_checkBox2->AutoSize = true;
			this->specific_min_checkBox2->Location = System::Drawing::Point(235, 316);
			this->specific_min_checkBox2->Name = L"specific_min_checkBox2";
			this->specific_min_checkBox2->Size = System::Drawing::Size(48, 24);
			this->specific_min_checkBox2->TabIndex = 35;
			this->specific_min_checkBox2->Text = L"<=";
			this->specific_min_checkBox2->UseVisualStyleBackColor = true;
			this->specific_min_checkBox2->Visible = false;
			this->specific_min_checkBox2->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::specific_min_checkBox2_Checked);
			// 
			// common_rav_checkBox1
			// 
			this->common_rav_checkBox1->AutoSize = true;
			this->common_rav_checkBox1->Location = System::Drawing::Point(64, 316);
			this->common_rav_checkBox1->Name = L"common_rav_checkBox1";
			this->common_rav_checkBox1->Size = System::Drawing::Size(48, 24);
			this->common_rav_checkBox1->TabIndex = 36;
			this->common_rav_checkBox1->Text = L"==";
			this->common_rav_checkBox1->UseVisualStyleBackColor = true;
			this->common_rav_checkBox1->Visible = false;
			this->common_rav_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::common_rav_checkBox1_Checked);
			// 
			// specific_rav_checkBox2
			// 
			this->specific_rav_checkBox2->AutoSize = true;
			this->specific_rav_checkBox2->Location = System::Drawing::Point(290, 316);
			this->specific_rav_checkBox2->Name = L"specific_rav_checkBox2";
			this->specific_rav_checkBox2->Size = System::Drawing::Size(48, 24);
			this->specific_rav_checkBox2->TabIndex = 37;
			this->specific_rav_checkBox2->Text = L"==";
			this->specific_rav_checkBox2->UseVisualStyleBackColor = true;
			this->specific_rav_checkBox2->Visible = false;
			this->specific_rav_checkBox2->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::specific_rav_checkBox2_Checked);
			// 
			// common_max_checkBox1
			// 
			this->common_max_checkBox1->AutoSize = true;
			this->common_max_checkBox1->Location = System::Drawing::Point(116, 316);
			this->common_max_checkBox1->Name = L"common_max_checkBox1";
			this->common_max_checkBox1->Size = System::Drawing::Size(48, 24);
			this->common_max_checkBox1->TabIndex = 38;
			this->common_max_checkBox1->Text = L">=";
			this->common_max_checkBox1->UseVisualStyleBackColor = true;
			this->common_max_checkBox1->Visible = false;
			this->common_max_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::common_max_checkBox1_Checked);
			// 
			// specific_maxcheckBox2
			// 
			this->specific_maxcheckBox2->AutoSize = true;
			this->specific_maxcheckBox2->Location = System::Drawing::Point(342, 316);
			this->specific_maxcheckBox2->Name = L"specific_maxcheckBox2";
			this->specific_maxcheckBox2->Size = System::Drawing::Size(48, 24);
			this->specific_maxcheckBox2->TabIndex = 39;
			this->specific_maxcheckBox2->Text = L">=";
			this->specific_maxcheckBox2->UseVisualStyleBackColor = true;
			this->specific_maxcheckBox2->Visible = false;
			this->specific_maxcheckBox2->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::specific_max_checkBox2_Checked);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(327, 167);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(125, 20);
			this->label7->TabIndex = 9;
			this->label7->Text = L"����� �������";
			// 
			// price_max_checkBox2
			// 
			this->price_max_checkBox2->AutoSize = true;
			this->price_max_checkBox2->Location = System::Drawing::Point(525, 314);
			this->price_max_checkBox2->Name = L"price_max_checkBox2";
			this->price_max_checkBox2->Size = System::Drawing::Size(48, 24);
			this->price_max_checkBox2->TabIndex = 45;
			this->price_max_checkBox2->Text = L">=";
			this->price_max_checkBox2->UseVisualStyleBackColor = true;
			this->price_max_checkBox2->Visible = false;
			this->price_max_checkBox2->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::price_max_checkBox1_Checked);
			// 
			// price_rav_checkBox2
			// 
			this->price_rav_checkBox2->AutoSize = true;
			this->price_rav_checkBox2->Location = System::Drawing::Point(473, 314);
			this->price_rav_checkBox2->Name = L"price_rav_checkBox2";
			this->price_rav_checkBox2->Size = System::Drawing::Size(48, 24);
			this->price_rav_checkBox2->TabIndex = 44;
			this->price_rav_checkBox2->Text = L"==";
			this->price_rav_checkBox2->UseVisualStyleBackColor = true;
			this->price_rav_checkBox2->Visible = false;
			this->price_rav_checkBox2->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::price_rav_checkBox2_Checked);
			// 
			// price_min_checkBox2
			// 
			this->price_min_checkBox2->AutoSize = true;
			this->price_min_checkBox2->Location = System::Drawing::Point(418, 314);
			this->price_min_checkBox2->Name = L"price_min_checkBox2";
			this->price_min_checkBox2->Size = System::Drawing::Size(48, 24);
			this->price_min_checkBox2->TabIndex = 43;
			this->price_min_checkBox2->Text = L"<=";
			this->price_min_checkBox2->UseVisualStyleBackColor = true;
			this->price_min_checkBox2->Visible = false;
			this->price_min_checkBox2->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::price_min_checkBox2_Checked);
			// 
			// price_textBox1
			// 
			this->price_textBox1->Location = System::Drawing::Point(418, 283);
			this->price_textBox1->MaxLength = 10;
			this->price_textBox1->Name = L"price_textBox1";
			this->price_textBox1->Size = System::Drawing::Size(100, 25);
			this->price_textBox1->TabIndex = 42;
			this->price_textBox1->Visible = false;
			this->price_textBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Request_rent_months::price_textBox1_KeyPress);
			// 
			// price_checkBox1
			// 
			this->price_checkBox1->AutoSize = true;
			this->price_checkBox1->Location = System::Drawing::Point(566, 261);
			this->price_checkBox1->Name = L"price_checkBox1";
			this->price_checkBox1->Size = System::Drawing::Size(15, 14);
			this->price_checkBox1->TabIndex = 41;
			this->price_checkBox1->UseVisualStyleBackColor = true;
			this->price_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::price_checkBox1_Checked);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(405, 255);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(155, 20);
			this->label6->TabIndex = 40;
			this->label6->Text = L"����� �� ����� (���)";
			// 
			// size_max_checkBox1
			// 
			this->size_max_checkBox1->AutoSize = true;
			this->size_max_checkBox1->Location = System::Drawing::Point(435, 221);
			this->size_max_checkBox1->Name = L"size_max_checkBox1";
			this->size_max_checkBox1->Size = System::Drawing::Size(48, 24);
			this->size_max_checkBox1->TabIndex = 48;
			this->size_max_checkBox1->Text = L">=";
			this->size_max_checkBox1->UseVisualStyleBackColor = true;
			this->size_max_checkBox1->Visible = false;
			this->size_max_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::size_max_checkBox2_Checked);
			// 
			// size_rav_checkBox2
			// 
			this->size_rav_checkBox2->AutoSize = true;
			this->size_rav_checkBox2->Location = System::Drawing::Point(383, 221);
			this->size_rav_checkBox2->Name = L"size_rav_checkBox2";
			this->size_rav_checkBox2->Size = System::Drawing::Size(48, 24);
			this->size_rav_checkBox2->TabIndex = 47;
			this->size_rav_checkBox2->Text = L"==";
			this->size_rav_checkBox2->UseVisualStyleBackColor = true;
			this->size_rav_checkBox2->Visible = false;
			this->size_rav_checkBox2->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::size_rav_checkBox2_Checked);
			// 
			// size_min_checkBox2
			// 
			this->size_min_checkBox2->AutoSize = true;
			this->size_min_checkBox2->Location = System::Drawing::Point(331, 221);
			this->size_min_checkBox2->Name = L"size_min_checkBox2";
			this->size_min_checkBox2->Size = System::Drawing::Size(48, 24);
			this->size_min_checkBox2->TabIndex = 46;
			this->size_min_checkBox2->Text = L"<=";
			this->size_min_checkBox2->UseVisualStyleBackColor = true;
			this->size_min_checkBox2->Visible = false;
			this->size_min_checkBox2->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::size_min_checkBox2_Checked);
			// 
			// size_textBox1
			// 
			this->size_textBox1->Location = System::Drawing::Point(331, 191);
			this->size_textBox1->MaxLength = 10;
			this->size_textBox1->Name = L"size_textBox1";
			this->size_textBox1->Size = System::Drawing::Size(100, 25);
			this->size_textBox1->TabIndex = 49;
			this->size_textBox1->Visible = false;
			this->size_textBox1->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Request_rent_months::size_textBox1_KeyPress);
			// 
			// telephone_textBox1
			// 
			this->telephone_textBox1->Location = System::Drawing::Point(525, 191);
			this->telephone_textBox1->Mask = L"+70000000000";
			this->telephone_textBox1->Name = L"telephone_textBox1";
			this->telephone_textBox1->Size = System::Drawing::Size(100, 25);
			this->telephone_textBox1->TabIndex = 50;
			this->telephone_textBox1->Visible = false;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(520, 167);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(70, 20);
			this->label8->TabIndex = 51;
			this->label8->Text = L"�������";
			// 
			// telephone_checkBox1
			// 
			this->telephone_checkBox1->AutoSize = true;
			this->telephone_checkBox1->Location = System::Drawing::Point(634, 171);
			this->telephone_checkBox1->Name = L"telephone_checkBox1";
			this->telephone_checkBox1->Size = System::Drawing::Size(15, 14);
			this->telephone_checkBox1->TabIndex = 52;
			this->telephone_checkBox1->UseVisualStyleBackColor = true;
			this->telephone_checkBox1->CheckedChanged += gcnew System::EventHandler(this, &Request_rent_months::telephone_checkBox1_Checked);
			// 
			// Request_rent_months
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightBlue;
			this->ClientSize = System::Drawing::Size(941, 563);
			this->Controls->Add(this->telephone_checkBox1);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->telephone_textBox1);
			this->Controls->Add(this->size_textBox1);
			this->Controls->Add(this->size_max_checkBox1);
			this->Controls->Add(this->size_rav_checkBox2);
			this->Controls->Add(this->size_min_checkBox2);
			this->Controls->Add(this->price_max_checkBox2);
			this->Controls->Add(this->price_rav_checkBox2);
			this->Controls->Add(this->price_min_checkBox2);
			this->Controls->Add(this->price_textBox1);
			this->Controls->Add(this->price_checkBox1);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->specific_maxcheckBox2);
			this->Controls->Add(this->common_max_checkBox1);
			this->Controls->Add(this->specific_rav_checkBox2);
			this->Controls->Add(this->common_rav_checkBox1);
			this->Controls->Add(this->specific_min_checkBox2);
			this->Controls->Add(this->common_min_checkBox1);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->exp_specific_textBox1);
			this->Controls->Add(this->payment_textBox1);
			this->Controls->Add(this->return_button1);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->sbros_button2);
			this->Controls->Add(this->request_button1);
			this->Controls->Add(this->data_maskedTextBox1);
			this->Controls->Add(this->full_name_maskedTextBox1);
			this->Controls->Add(this->exp_specific_checkBox1);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->exp_common_checkBox1);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->size_checkBox1);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->data_checkBox1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->full_name_checkBox1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"Request_rent_months";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"������";
			this->Load += gcnew System::EventHandler(this, &Request_rent_months::Request_Load);
			this->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &Request_rent_months::size_textBox1_KeyPress);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void Request_Load(System::Object^ sender, System::EventArgs^ e) {
	}
		   //�������� ������������ ����� ������//////////////////////////////////////////////////////////
	private: System::Void  full_name_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e)
	{
		full_name_maskedTextBox1->Visible = true;
		if (!full_name_checkBox1->Checked)
			full_name_maskedTextBox1->Visible = false;
	}
	private: System::Void   data_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e)
	{
		data_maskedTextBox1->Visible = true;
		if (!data_checkBox1->Checked)
			data_maskedTextBox1->Visible = false;
	}



	private: System::Void  exp_common_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e)
	{
		payment_textBox1->Visible = true;
		common_min_checkBox1->Visible = true;
		common_max_checkBox1->Visible = true;
		common_rav_checkBox1->Visible = true;
		if (!exp_common_checkBox1->Checked)
		{
			payment_textBox1->Visible = false;
			common_min_checkBox1->Visible = false;
			common_max_checkBox1->Visible = false;
			common_rav_checkBox1->Visible = false;
		}
	}
	private: System::Void exp_specific_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e)
	{
		exp_specific_textBox1->Visible = true;
		specific_min_checkBox2->Visible = true;
		specific_maxcheckBox2->Visible = true;
		specific_rav_checkBox2->Visible = true;
		if (!exp_specific_checkBox1->Checked)
		{
			exp_specific_textBox1->Visible = false;
			specific_min_checkBox2->Visible = false;
			specific_maxcheckBox2->Visible = false;
			specific_rav_checkBox2->Visible = false;
		}
	}
	private: System::Void price_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e)
	{
		price_textBox1->Visible = true;
		price_min_checkBox2->Visible = true;
		price_max_checkBox2->Visible = true;
		price_rav_checkBox2->Visible = true;
		if (!price_checkBox1->Checked)
		{
			price_textBox1->Visible = false;
			price_min_checkBox2->Visible = false;
			price_max_checkBox2->Visible = false;
			price_rav_checkBox2->Visible = false;
		}
	}
	private: System::Void speciality_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e)
	{
		size_textBox1->Visible = true;
		size_min_checkBox2->Visible = true;
		size_max_checkBox1->Visible = true;
		size_rav_checkBox2->Visible = true;
		if (!size_checkBox1->Checked)
		{
			size_textBox1->Visible = false;
			size_min_checkBox2->Visible = false;
			size_max_checkBox1->Visible = false;
			size_rav_checkBox2->Visible = false;
		}
	}
	private: System::Void telephone_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e)
	{
		telephone_textBox1->Visible = true;

		if (!telephone_checkBox1->Checked)
		{
			telephone_textBox1->Visible = false;

		}
	}



		   //������///////////////////////////////////////////////////////////////////////////////////
	private: System::Void request_button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		prov = false;
		int spros = 0;				//��������� ��� �������� ���-�� ����� �������
		int spros_prov = 0;			//���������� ��� �������� ���-�� ��������� �����
		if (full_name_checkBox1->Checked)
		{
			if (!full_name_maskedTextBox1->MaskCompleted) {
				MessageBox::Show("���� �� ���������� ������  �� ����� ����,������� ����� ��� ������� �������", "������������ ���� ���!", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}
			spros++;
		}
		if (data_checkBox1->Checked)
		{
			if (!data_maskedTextBox1->MaskCompleted) {
				MessageBox::Show("���� �� ���������� ������  �� ����� ����,������� ����� ��� ������� �������", "������������ ���� ���� ��������!", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}
			spros++;
		}

		if (size_checkBox1->Checked)
		{
			if (size_textBox1->Text == String::Empty) {
				MessageBox::Show("���� �� ���������� ������  �� ����� ����, ������� ����� ��� ������� ������", "������������ ���� �������������!", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}
			spros++;
		}

		if (exp_common_checkBox1->Checked)
		{
			if (payment_textBox1->Text == String::Empty || common == 0)
			{
				MessageBox::Show("���� �� ���������� ������  �� ����� ����,������� ����� ��� ������� �������", "������������ ���� ������ ����� ������!", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}spros++;
		}
		if (exp_specific_checkBox1->Checked)
		{
			if (exp_specific_textBox1->Text == String::Empty || specific == 0)
			{
				MessageBox::Show("���� �� ���������� ������  �� ����� ����,������� ����� ��� ������� �������", "������������ ���� ����� ������ �� ����������� !", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}spros++;

		}


		if (price_checkBox1->Checked)
		{
			if (price_textBox1->Text == String::Empty || prices == 0)
			{
				MessageBox::Show("���� �� ���������� ������  �� ����� ����,������� ����� ��� ������� �������", "������������ ���� ����� ������ �� ����������� !", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}spros++;

		}
		if (telephone_checkBox1->Checked)
		{
			if (!telephone_textBox1->MaskCompleted) {
				MessageBox::Show("���� �� ���������� ������  �� ����� ����,������� ����� ��� ������� �������", "������������ ���� ����� ��������!", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}
			spros++;
		}

		StreamReader^ openfile = gcnew StreamReader("rent_months.txt");
		for (int i = 0; i < dataGridView1->Rows->Count; i++)
		{
			dataGridView1->Rows->Clear();
		}
		while (openfile->Peek() >= 0)
		{
			spros_prov = 0;
			array <String^>^ cells = (openfile->ReadLine())->Split('/', '\0');
			if (full_name_checkBox1->Checked)
			{
				if (full_name_maskedTextBox1->Text->CompareTo(cells[0]))
				{

				}
				else spros_prov++;;
			}
			if (data_checkBox1->Checked)
			{
				if (data_maskedTextBox1->Text->CompareTo(cells[1]))
				{

				}
				else spros_prov++;
			}


			if (telephone_checkBox1->Checked)
			{
				if (telephone_textBox1->Text->CompareTo(cells[6]))
				{

				}
				else spros_prov++;;
			}

			if (exp_common_checkBox1->Checked)
			{
				if (common_min_checkBox1->Checked)
				{
					if (Int32::Parse(this->payment_textBox1->Text) >= Int32::Parse(cells[3]))
					{
						spros_prov++;
					}
				}
				if (common_max_checkBox1->Checked)
				{
					if (Int32::Parse(this->payment_textBox1->Text) <= Int32::Parse(cells[3]))
					{
						spros_prov++;
					}
				}
				if (common_rav_checkBox1->Checked)
				{
					if (Int32::Parse(this->payment_textBox1->Text) == Int32::Parse(cells[3]))
					{
						spros_prov++;
					}
				}

			}
			if (exp_specific_checkBox1->Checked)
			{
				if (specific_min_checkBox2->Checked)
				{
					if (Int32::Parse(this->exp_specific_textBox1->Text) >= Int32::Parse(cells[4]))
					{
						spros_prov++;
					}
				}
				if (specific_maxcheckBox2->Checked)
				{
					if (Int32::Parse(this->exp_specific_textBox1->Text) <= Int32::Parse(cells[4]))
					{
						spros_prov++;
					}
				}
				if (specific_rav_checkBox2->Checked)
				{
					if (Int32::Parse(this->exp_specific_textBox1->Text) == Int32::Parse(cells[4]))
					{
						spros_prov++;
					}
				}
			}
			if (price_checkBox1->Checked)
			{
				if (price_min_checkBox2->Checked)
				{
					if (Int32::Parse(this->price_textBox1->Text) >= Int32::Parse(cells[5]))
					{
						spros_prov++;
					}
				}
				if (price_max_checkBox2->Checked)
				{
					if (Int32::Parse(this->price_textBox1->Text) <= Int32::Parse(cells[5]))
					{
						spros_prov++;
					}
				}
				if (price_rav_checkBox2->Checked)
				{
					if (Int32::Parse(this->price_textBox1->Text) == Int32::Parse(cells[5]))
					{
						spros_prov++;
					}
				}

			}

			if (size_checkBox1->Checked)
			{
				if (size_min_checkBox2->Checked)
				{
					if (Int32::Parse(this->size_textBox1->Text) >= Int32::Parse(cells[2]))
					{
						spros_prov++;
					}
				}
				if (size_max_checkBox1->Checked)
				{
					if (Int32::Parse(this->size_textBox1->Text) <= Int32::Parse(cells[2]))
					{
						spros_prov++;
					}
				}
				if (size_rav_checkBox2->Checked)
				{
					if (Int32::Parse(this->size_textBox1->Text) == Int32::Parse(cells[2]))
					{
						spros_prov++;
					}
				}
			}


			if (spros == spros_prov && spros != 0)
			{
				dataGridView1->Rows->Add(cells);
				prov = true;
			}

		}
		if (prov == false)
		{
			if (spros == 0)
			{
				MessageBox::Show("�� �� ��������� ������ ��� ������ ��������, ��������� �� � ���������� �����", "�����", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}
			else MessageBox::Show("�� ������ ������� ������ �� �������", "�����", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
	}
		   //�����///////////////////////////////////////////////////////////////////////////
	private:System::Void  sbros_button2_Click(System::Object^ sender, System::EventArgs^ e)
	{
		dataGridView1->Rows->Clear();
		full_name_maskedTextBox1->Clear();
		data_maskedTextBox1->Clear();
		price_textBox1->Clear();
		size_textBox1->Clear();
		telephone_textBox1->Clear();

		payment_textBox1->Clear();
		exp_specific_textBox1->Clear();
		full_name_checkBox1->Checked = false;
		data_checkBox1->Checked = false;

		size_checkBox1->Checked = false;

		exp_common_checkBox1->Checked = false;
		exp_specific_checkBox1->Checked = false;
		price_checkBox1->Checked = false;
		telephone_checkBox1->Checked = false;

		if (size_max_checkBox1->Checked)size_max_checkBox1->Checked = false;
		if (size_min_checkBox2->Checked)size_min_checkBox2->Checked = false;
		if (size_rav_checkBox2->Checked)size_rav_checkBox2->Checked = false;
		if (common_max_checkBox1->Checked)common_max_checkBox1->Checked = false;
		if (common_min_checkBox1->Checked)common_min_checkBox1->Checked = false;
		if (common_rav_checkBox1->Checked)common_rav_checkBox1->Checked = false;
		if (specific_min_checkBox2->Checked)specific_min_checkBox2->Checked = false;
		if (specific_maxcheckBox2->Checked)specific_maxcheckBox2->Checked = false;
		if (specific_rav_checkBox2->Checked)specific_rav_checkBox2->Checked = false;
		if (price_min_checkBox2->Checked)price_min_checkBox2->Checked = false;
		if (price_max_checkBox2->Checked)price_max_checkBox2->Checked = false;
		if (price_rav_checkBox2->Checked)price_rav_checkBox2->Checked = false;
	}
		   //����������� � ��//////////////////////////////////////////////////////////////////
	private:System::Void  return_button2_Click(System::Object^ sender, System::EventArgs^ e)
	{
		System::Windows::Forms::DialogResult what = MessageBox::Show("������ ��������� �������� � ��������?", "��������������", MessageBoxButtons::YesNo, MessageBoxIcon::Question);
		if (what == System::Windows::Forms::DialogResult::No)
			return;
		else {
			this->Close();
		}
	}

	private: System::Void payment_textBox1_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		char number = e->KeyChar;

		if ((e->KeyChar != (char)8) && (e->KeyChar < (char)48 || e->KeyChar >(char)57)) {
			e->Handled = true;
		}
	}
	private: System::Void exp_specific_textBox1_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		char number = e->KeyChar;

		if ((e->KeyChar != (char)8) && (e->KeyChar < (char)48 || e->KeyChar >(char)57)) {
			e->Handled = true;
		}
	}

	private: System::Void price_textBox1_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		char number = e->KeyChar;

		if ((e->KeyChar != (char)8) && (e->KeyChar < (char)48 || e->KeyChar >(char)57)) {
			e->Handled = true;
		}
	}





	private: System::Void common_max_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e) {
		common_rav_checkBox1->Enabled = false;
		common_min_checkBox1->Enabled = false;
		common = 1;
		if (!common_max_checkBox1->Checked)
		{
			common = 0;
			common_rav_checkBox1->Enabled = true;
			common_min_checkBox1->Enabled = true;

		}
	}

	private: System::Void common_min_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e) {
		common_rav_checkBox1->Enabled = false;
		common_max_checkBox1->Enabled = false;
		common = 1;
		if (!common_min_checkBox1->Checked)
		{
			common = 0;
			common_rav_checkBox1->Enabled = true;
			common_max_checkBox1->Enabled = true;

		}
	}
	private: System::Void common_rav_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e) {
		common_min_checkBox1->Enabled = false;
		common_max_checkBox1->Enabled = false;
		common = 1;
		if (!common_rav_checkBox1->Checked)
		{
			common = 0;
			common_min_checkBox1->Enabled = true;
			common_max_checkBox1->Enabled = true;

		}
	}
	private: System::Void size_rav_checkBox2_Checked(System::Object^ sender, System::EventArgs^ e) {
		size_min_checkBox2->Enabled = false;
		size_max_checkBox1->Enabled = false;
		sizes = 1;
		if (!size_rav_checkBox2->Checked)
		{
			sizes = 0;
			size_min_checkBox2->Enabled = true;
			size_max_checkBox1->Enabled = true;

		}
	}

	private: System::Void size_max_checkBox2_Checked(System::Object^ sender, System::EventArgs^ e) {
		size_rav_checkBox2->Enabled = false;
		size_min_checkBox2->Enabled = false;
		sizes = 1;
		if (!size_max_checkBox1->Checked)
		{
			sizes = 0;
			size_rav_checkBox2->Enabled = true;
			size_min_checkBox2->Enabled = true;

		}
	}

	private: System::Void size_min_checkBox2_Checked(System::Object^ sender, System::EventArgs^ e) {
		size_rav_checkBox2->Enabled = false;
		size_max_checkBox1->Enabled = false;
		sizes = 1;
		if (!size_min_checkBox2->Checked)
		{
			sizes = 0;
			size_rav_checkBox2->Enabled = true;
			size_max_checkBox1->Enabled = true;

		}
	}

	private: System::Void specific_max_checkBox2_Checked(System::Object^ sender, System::EventArgs^ e) {
		specific_rav_checkBox2->Enabled = false;
		specific_min_checkBox2->Enabled = false;
		specific = 1;
		if (!specific_maxcheckBox2->Checked)
		{
			specific = 0;
			specific_rav_checkBox2->Enabled = true;
			specific_min_checkBox2->Enabled = true;

		}
	}
	private: System::Void specific_min_checkBox2_Checked(System::Object^ sender, System::EventArgs^ e) {
		specific_rav_checkBox2->Enabled = false;
		specific_maxcheckBox2->Enabled = false;
		specific = 1;
		if (!specific_min_checkBox2->Checked)
		{
			specific = 0;
			specific_rav_checkBox2->Enabled = true;
			specific_maxcheckBox2->Enabled = true;

		}
	}
	private: System::Void specific_rav_checkBox2_Checked(System::Object^ sender, System::EventArgs^ e) {
		specific_maxcheckBox2->Enabled = false;
		specific_min_checkBox2->Enabled = false;
		specific = 1;
		if (!specific_rav_checkBox2->Checked)
		{
			specific = 0;
			specific_maxcheckBox2->Enabled = true;
			specific_min_checkBox2->Enabled = true;

		}
	}
	private: System::Void price_max_checkBox1_Checked(System::Object^ sender, System::EventArgs^ e) {
		price_rav_checkBox2->Enabled = false;
		price_min_checkBox2->Enabled = false;
		prices = 1;
		if (!price_max_checkBox2->Checked)
		{
			prices = 0;
			price_rav_checkBox2->Enabled = true;
			price_min_checkBox2->Enabled = true;

		}
	}
	private: System::Void price_min_checkBox2_Checked(System::Object^ sender, System::EventArgs^ e) {
		price_rav_checkBox2->Enabled = false;
		price_max_checkBox2->Enabled = false;
		prices = 1;
		if (!price_min_checkBox2->Checked)
		{
			prices = 0;
			price_rav_checkBox2->Enabled = true;
			price_max_checkBox2->Enabled = true;

		}
	}

	private: System::Void price_rav_checkBox2_Checked(System::Object^ sender, System::EventArgs^ e) {
		price_max_checkBox2->Enabled = false;
		price_min_checkBox2->Enabled = false;
		prices = 1;
		if (!price_rav_checkBox2->Checked)
		{
			prices = 0;
			price_max_checkBox2->Enabled = true;
			price_min_checkBox2->Enabled = true;

		}
	}
	private: System::Void price_max_checkBox2_Checked(System::Object^ sender, System::EventArgs^ e) {
		price_rav_checkBox2->Enabled = false;
		price_min_checkBox2->Enabled = false;
		prices = 1;
		if (!specific_maxcheckBox2->Checked)
		{
			prices = 0;
			price_rav_checkBox2->Enabled = true;
			price_min_checkBox2->Enabled = true;

		}
	}




	private: System::Void size_textBox1_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {

		char number = e->KeyChar;

		if ((e->KeyChar != (char)8) && (e->KeyChar < (char)48 || e->KeyChar >(char)57)) {
			e->Handled = true;
		}
	}



	};
}
