#include "Main_menu.h"
#include <Windows.h>
#include <iostream>
using namespace Practice; // �������� �������
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Application::Run(gcnew Main_menu);
	extern int flag;
	return 0;
}