#pragma once
namespace Practice {
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	/// <summary>
	/// ������ ��� password
	/// </summary>
	public ref class Password : public System::Windows::Forms::Form
	{
	public:
		Password(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}
	public: bool prov_pass = false;
	private: System::Windows::Forms::Button^ return_button1;
	public:
		String^ pass_right;					//���������� ��� �������� ������
	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Password()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::TextBox^ password_textBox1;
	private: System::Windows::Forms::Button^ next_button1;
	private: System::Windows::Forms::Button^ change_button1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ next_change_button1;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ change_password_textBox1;
	private: System::Windows::Forms::Button^ change_password_button1;

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Password::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->password_textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->next_button1 = (gcnew System::Windows::Forms::Button());
			this->change_button1 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->next_change_button1 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->change_password_textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->change_password_button1 = (gcnew System::Windows::Forms::Button());
			this->return_button1 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei UI", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(122, 144);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(402, 25);
			this->label1->TabIndex = 0;
			this->label1->Text = L"������� ������ ��� ���������� ������";
			// 
			// password_textBox1
			// 
			this->password_textBox1->Location = System::Drawing::Point(249, 190);
			this->password_textBox1->Name = L"password_textBox1";
			this->password_textBox1->PasswordChar = '*';
			this->password_textBox1->Size = System::Drawing::Size(100, 25);
			this->password_textBox1->TabIndex = 1;
			// 
			// next_button1
			// 
			this->next_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->next_button1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei UI", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->next_button1->Location = System::Drawing::Point(222, 221);
			this->next_button1->Name = L"next_button1";
			this->next_button1->Size = System::Drawing::Size(155, 49);
			this->next_button1->TabIndex = 2;
			this->next_button1->Text = L"����������";
			this->next_button1->UseVisualStyleBackColor = false;
			this->next_button1->Click += gcnew System::EventHandler(this, &Password::next_button1_Click);
			// 
			// change_button1
			// 
			this->change_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->change_button1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei UI", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->change_button1->Location = System::Drawing::Point(12, 478);
			this->change_button1->Name = L"change_button1";
			this->change_button1->Size = System::Drawing::Size(201, 60);
			this->change_button1->TabIndex = 3;
			this->change_button1->Text = L"������� ������";
			this->change_button1->UseVisualStyleBackColor = false;
			this->change_button1->Click += gcnew System::EventHandler(this, &Password::change_button1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei UI", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(103, 144);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(437, 25);
			this->label2->TabIndex = 4;
			this->label2->Text = L"������� ������ ������, ��� �������������";
			this->label2->Visible = false;
			// 
			// next_change_button1
			// 
			this->next_change_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->next_change_button1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei UI", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->next_change_button1->Location = System::Drawing::Point(222, 221);
			this->next_change_button1->Name = L"next_change_button1";
			this->next_change_button1->Size = System::Drawing::Size(155, 49);
			this->next_change_button1->TabIndex = 5;
			this->next_change_button1->Text = L"����������";
			this->next_change_button1->UseVisualStyleBackColor = false;
			this->next_change_button1->Visible = false;
			this->next_change_button1->Click += gcnew System::EventHandler(this, &Password::next_change_button1_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei UI", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(191, 312);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(231, 25);
			this->label3->TabIndex = 6;
			this->label3->Text = L"������� ����� ������";
			this->label3->Visible = false;
			// 
			// change_password_textBox1
			// 
			this->change_password_textBox1->Location = System::Drawing::Point(249, 355);
			this->change_password_textBox1->Name = L"change_password_textBox1";
			this->change_password_textBox1->PasswordChar = '*';
			this->change_password_textBox1->Size = System::Drawing::Size(100, 25);
			this->change_password_textBox1->TabIndex = 7;
			this->change_password_textBox1->Visible = false;
			// 
			// change_password_button1
			// 
			this->change_password_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->change_password_button1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei UI", 12, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			this->change_password_button1->Location = System::Drawing::Point(396, 355);
			this->change_password_button1->Name = L"change_password_button1";
			this->change_password_button1->Size = System::Drawing::Size(113, 29);
			this->change_password_button1->TabIndex = 8;
			this->change_password_button1->Text = L"��������";
			this->change_password_button1->UseVisualStyleBackColor = false;
			this->change_password_button1->Visible = false;
			this->change_password_button1->Click += gcnew System::EventHandler(this, &Password::change_password_button1_Click);
			// 
			// return_button1
			// 
			this->return_button1->BackColor = System::Drawing::Color::LightSteelBlue;
			this->return_button1->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei UI", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->return_button1->Location = System::Drawing::Point(355, 12);
			this->return_button1->Name = L"return_button1";
			this->return_button1->Size = System::Drawing::Size(283, 38);
			this->return_button1->TabIndex = 9;
			this->return_button1->Text = L"��������� � ������ ������";
			this->return_button1->UseVisualStyleBackColor = false;
			this->return_button1->Click += gcnew System::EventHandler(this, &Password::return_button1_Click);
			// 
			// Password
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::LightBlue;
			this->ClientSize = System::Drawing::Size(650, 570);
			this->Controls->Add(this->return_button1);
			this->Controls->Add(this->change_password_button1);
			this->Controls->Add(this->change_password_textBox1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->next_change_button1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->change_button1);
			this->Controls->Add(this->next_button1);
			this->Controls->Add(this->password_textBox1);
			this->Controls->Add(this->label1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei UI", 10.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"Password";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"���� ������";
			this->Load += gcnew System::EventHandler(this, &Password::Password_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Password_Load(System::Object^ sender, System::EventArgs^ e) {
	}
		   //�������� ������/////////////////////////////////////////////////////////////////////
	private: System::Void next_button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		StreamReader^ pass = gcnew  StreamReader("pass.txt");
		pass_right = pass->ReadLine();
		pass->Close();
		String^ pass_input;
		cli::array<Char>^ passw;
		passw = password_textBox1->Text->ToCharArray();
		for (int i = 0; i < password_textBox1->TextLength; i++) {

			pass_input += (wchar_t)passw[i];
		}

		if (pass_input == pass_right)
		{

			prov_pass = true;
			this->Hide();
		}
		else {

			password_textBox1->Text = "";
			MessageBox::Show("�������� ������!\n��������� ����.", "������", MessageBoxButtons::OK, MessageBoxIcon::Error);

		}

	}
		   //����� ������//////////////////////////////////////////////////////////////////////////////
	private: System::Void change_button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		label1->Visible = false;
		next_button1->Visible = false;
		label2->Visible = true;
		next_change_button1->Visible = true;


	}
	private: System::Void next_change_button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		StreamReader^ pass = gcnew  StreamReader("pass.txt");
		pass_right = pass->ReadLine();
		pass->Close();
		String^ pass_input;
		cli::array<Char>^ pass_buff;
		pass_buff = password_textBox1->Text->ToCharArray();
		for (int i = 0; i < password_textBox1->TextLength; i++) {

			pass_input += (wchar_t)pass_buff[i];
		}

		if (pass_input == pass_right)
		{
			label3->Visible = true;
			change_password_textBox1->Visible = true;
			change_password_button1->Visible = true;
		}
		else {

			password_textBox1->Text = "";
			MessageBox::Show("�������� ������!\n��������� ����.", "������", MessageBoxButtons::OK, MessageBoxIcon::Error);

		}
	}
	private: System::Void change_password_button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		if (change_password_textBox1->Text == String::Empty)
		{
			MessageBox::Show("�� �� ����� ������ ��� ���������", "�������� ����", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		}
		else {
			StreamWriter^ new_pass = gcnew StreamWriter("pass.txt");
			pass_right = change_password_textBox1->Text;
			new_pass->Write(pass_right);
			new_pass->WriteLine();
			new_pass->Close();
			MessageBox::Show("������ ��������", "�����", MessageBoxButtons::OK, MessageBoxIcon::Information);
			label2->Visible = false;
			label3->Visible = false;
			next_change_button1->Visible = false;
			change_password_button1->Visible = false;
			change_password_textBox1->Visible = false;
			label1->Visible = true;
			next_button1->Visible = true;
			password_textBox1->Clear();
		}

		change_password_textBox1->Clear();
	}
		   //����������� � ��/////////////////////////////////////////////////////////////////////
	private: System::Void return_button1_Click(System::Object^ sender, System::EventArgs^ e)
	{
		this->Close();
	}

	};
}
